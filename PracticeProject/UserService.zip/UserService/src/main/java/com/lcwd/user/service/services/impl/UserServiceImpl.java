package com.lcwd.user.service.services.impl;

import com.lcwd.user.service.entities.User;
import com.lcwd.user.service.expetion.ResourceNotFoundException;
import com.lcwd.user.service.repositories.UserRepository;
import com.lcwd.user.service.services.UserService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Optional;
import java.util.UUID;

@Service

public class UserServiceImpl implements UserService {

    @Autowired
    private UserRepository userRepository;
    @Override
    public User saveUser(User user) {
        String randomUserID = UUID.randomUUID().toString();
        user.setUserID(randomUserID);
        return userRepository.save(user);
    }

    @Override
    public List<User> getAllUser() {
        return userRepository.findAll();
    }

    @Override
    public User getUser(String userId) {
        return userRepository.findById(userId).orElseThrow(()-> new ResourceNotFoundException("User with given id is not found on server" + userId));
    }

    @Override
    public User deleteUser(String userId) {
        Optional<User> user = userRepository.findById(userId);
        if (user.isPresent()) {
            userRepository.deleteById(userId);
            return user.get(); // Return the deleted user
        } else {
            throw new ResourceNotFoundException("User with ID " + userId + " not found");
        }
    }


    @Override
    public User updateUser(String userId, User updatedUserData) {
        Optional<User> existingUser = userRepository.findById(userId);

        if (existingUser.isPresent()) {
            User user = existingUser.get();

            user.setName(updatedUserData.getName());
            user.setEmail(updatedUserData.getEmail());
            user.setAbout(updatedUserData.getAbout());

            return userRepository.save(user); // Save updated user
        } else {
            throw new ResourceNotFoundException("User with ID " + userId + " not found");
        }
    }

}
