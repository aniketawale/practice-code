package com.lcwd.service.registary;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ServiceRegistaryApplicationTests {

	@Test
	void contextLoads() {
	}

}
